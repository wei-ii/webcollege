
## Скрипт 1: `prepare_environment.sh` - Подготовка окружения

```bash
#!/bin/bash

###############################################################################
# Скрипт подготовки окружения для сбора дампа памяти
# Объяснение синтаксиса для новичков:
###############################################################################

# -*-*- ОБЪЯСНЕНИЕ ПЕРВОЙ СТРОКИ -*-*-
#!/bin/bash
# Это называется "shebang". Она указывает системе, какой интерпретатор 
# использовать для выполнения скрипта. /bin/bash - это путь к Bash интерпретатору.

# -*-*- ОПРЕДЕЛЕНИЕ ПЕРЕМЕННЫХ -*-*-
TARGET_IP="192.168.1.10"          # IP адрес целевой машины (Ubuntu)
KALI_IP="192.168.1.11"           # IP адрес машины исследователя (Kali)
WORK_DIR="/root/ram_capture"     # Рабочая директория
PORT="8080"                      # Порт для HTTP сервера

# Объяснение:
# - Переменные хранят данные, которые можно переиспользовать
# - Имена переменных пишутся ЗАГЛАВНЫМИ_БУКВАМИ (соглашение)
# - Значения присваиваются через = без пробелов
# - Двойные кавычки " защищают от разбивки по пробелам

# -*-*- ФУНКЦИЯ ДЛЯ ВЫВОДА СООБЩЕНИЙ -*-*-
print_message() {
    local message=$1              # local означает, что переменная видна только внутри функции
    local type=${2:-"INFO"}       # ${2:-"INFO"} - если второй параметр не передан, используем "INFO"
    
    echo "[$type] $(date '+%Y-%m-%d %H:%M:%S') - $message"
    # echo - вывод текста в консоль
    # $(date '+%Y-%m-%d %H:%M:%S') - подставляет текущую дату и время
    # $message - содержимое переменной message
}

# -*-*- ФУНКЦИЯ ПРОВЕРКИ ОШИБОК -*-*-
check_error() {
    local exit_code=$1            # $1 - первый переданный параметр (код выхода предыдущей команды)
    local error_message=$2        # $2 - второй параметр (сообщение об ошибке)
    
    if [ $exit_code -ne 0 ]; then  # -ne означает "not equal" (не равно)
        print_message "ОШИБКА: $error_message" "ERROR"
        exit $exit_code           # Завершаем скрипт с кодом ошибки
    fi
    # if [ условие ] - конструкция условного оператора
    # $? - специальная переменная, содержащая код выхода последней команды
    # 0 обычно означает успех, другие числа - ошибки
}

# -*-*- ОСНОВНОЙ КОД СКРИПТА -*-*-
print_message "Начинаем подготовку окружения для сбора RAM"

# -*-*- Проверка прав пользователя -*-*-
if [ "$EUID" -ne 0 ]; then        # Проверяем, запущен ли скрипт от root
    print_message "Скрипт должен запускаться с правами root!" "WARNING"
    exit 1
fi

# -*-*- Создание рабочей директории -*-*-
print_message "Создаем рабочую директорию: $WORK_DIR"
mkdir -p "$WORK_DIR"              # -p создает все родительские директории, если их нет
check_error $? "Не удалось создать директорию $WORK_DIR"

# -*-*- Переход в рабочую директорию -*-*-
cd "$WORK_DIR" || exit 1          # || означает "ИЛИ" - если cd не удался, выходим
print_message "Перешли в директорию: $(pwd)"  # $(pwd) подставляет текущий путь

# -*-*- Скачивание AVML -*-*-
print_message "Скачиваем AVML инструмент..."
wget -q "https://github.com/microsoft/avml/releases/latest/download/avml" 
# -q означает "quiet" (тихий режим, без лишнего вывода)

check_error $? "Ошибка при скачивании AVML"

# -*-*- Установка прав выполнения -*-*-
chmod +x avml                    # +x добавляет права на выполнение (execute)
print_message "Установлены права на выполнение для avml"

# -*-*- Проверка сети -*-*-
print_message "Проверяем доступность целевой машины $TARGET_IP..."
ping -c 2 "$TARGET_IP" > /dev/null 2>&1  # -c 2 означает 2 пакета, > /dev/null перенаправляет вывод в никуда
if [ $? -eq 0 ]; then            # -eq означает "equal" (равно)
    print_message "Целевая машина доступна" "SUCCESS"
else
    print_message "Целевая машина НЕ доступна!" "WARNING"
fi

# -*-*- Финальный отчет -*-*-
print_message "Подготовка завершена!" "SUCCESS"
echo "=== СВОДКА ==="
echo "Рабочая директория: $WORK_DIR"
echo "Размер avml: $(du -h avml | cut -f1)"  # du -h показывает размер, cut берет только первое поле
echo "Для продолжения запустите: ./start_capture.sh"
echo "=========================="
```

## Скрипт 2: `start_capture.sh` - Запуск сбора памяти

```bash
#!/bin/bash

###############################################################################
# Скрипт для запуска процесса сбора дампа памяти
###############################################################################

# -*-*- ПОДКЛЮЧЕНИЕ НАСТРОЕК -*-*-
CONFIG_FILE="config.cfg"          # Файл с настройками

# Проверяем существование файла конфигурации
if [ -f "$CONFIG_FILE" ]; then    # -f проверяет, существует ли файл
    source "$CONFIG_FILE"         # source выполняет команды из файла в текущей сессии
    print_message "Конфигурация загружена из $CONFIG_FILE"
else
    # Если файла нет, используем значения по умолчанию
    TARGET_IP="192.168.1.10"
    KALI_IP="192.168.1.11" 
    WORK_DIR="/root/ram_capture"
    PORT="8080"
    print_message "Используются настройки по умолчанию" "WARNING"
fi

# -*-*- ФУНКЦИЯ ОЖИДАНИЯ -*-*-
wait_for_user() {
    local message=$1
    echo ""
    read -p ">>> $message (нажмите Enter для продолжения...) " 
    # read -p читает ввод пользователя с подсказкой
}

# -*-*- ФУНКЦИЯ ЗАПУСКА HTTP СЕРВЕРА -*-*-
start_http_server() {
    local port=$1
    local directory=$2
    
    print_message "Запускаем HTTP сервер на порту $port в директории $directory"
    
    # Запускаем сервер в фоновом режиме (& в конце)
    python3 -m http.server "$port" > server.log 2>&1 &
    # > server.log перенаправляет стандартный вывод в файл
    # 2>&1 перенаправляет stderr (ошибки) в stdout (вывод)
    # & в конце запускает процесс в фоне
    
    SERVER_PID=$!                 # $! содержит PID последнего фонового процесса
    print_message "HTTP сервер запущен с PID: $SERVER_PID"
    
    # Ждем немного для инициализации сервера
    sleep 2
}

# -*-*- ФУНКЦИЯ ОСТАНОВКИ СЕРВЕРА -*-*-
stop_http_server() {
    if [ ! -z "$SERVER_PID" ]; then  # ! -z проверяет, что переменная НЕ пустая
        print_message "Останавливаем HTTP сервер (PID: $SERVER_PID)"
        kill "$SERVER_PID" 2>/dev/null  # kill отправляет сигнал завершения процессу
        wait "$SERVER_PID" 2>/dev/null  # wait ждет завершения процесса
    fi
}

# -*-*- ОСНОВНОЙ ПРОЦЕСС -*-*-
print_message "Начинаем процесс сбора дампа памяти"

# -*-*- Шаг 1: Запуск сервера на Kali -*-*-
cd "$WORK_DIR" || exit 1
start_http_server "$PORT" "$WORK_DIR"

wait_for_user "Убедитесь, что HTTP сервер запущен на порту $PORT"

# -*-*- Шаг 2: Инструкции для целевой машины -*-*-
echo ""
echo "=== ИНСТРУКЦИЯ ДЛЯ ЦЕЛЕВОЙ МАШИНЫ (Ubuntu) ==="
echo "Выполните на целевой машине следующие команды:"
echo "----------------------------------------"
echo "cd /tmp"
echo "wget http://$KALI_IP:$PORT/avml"
echo "chmod +x avml"
echo "sudo ./avml memory_dump.raw"
echo "----------------------------------------"
echo "После создания дампа выполните:"
echo "python3 -m http.server 8081"
echo ""

wait_for_user "Дамп создан на целевой машине и запущен сервер на порту 8081?"

# -*-*- Шаг 3: Скачивание дампа -*-*-
print_message "Скачиваем дамп с целевой машины..."
wget -q "http://${TARGET_IP}:8081/memory_dump.raw"
check_error $? "Ошибка при скачивании дампа памяти"

# -*-*- Шаг 4: Останавливаем сервер -*-*-
stop_http_server

print_message "Дамп памяти успешно получен!" "SUCCESS"
```

## Скрипт 3: `calculate_hashes.sh` - Расчет хэш-сумм

```bash
#!/bin/bash

###############################################################################
# Скрипт для расчета и верификации хэш-сумм дампа памяти
###############################################################################

# -*-*- НАСТРОЙКИ -*-*-
WORK_DIR="/root/ram_capture"
DUMP_FILE="memory_dump.raw"
HASH_FILE="forensic_hashes.txt"
TIMESTAMP=$(date '+%Y-%m-%d_%H-%M-%S')  # Сохраняем дату в переменную

# -*-*- ФУНКЦИЯ РАСЧЕТА ХЭШЕЙ -*-*-
calculate_hashes() {
    local file_path=$1
    local output_file=$2
    
    print_message "Начинаем расчет хэш-сумм для файла: $file_path"
    
    # Проверяем существование файла
    if [ ! -f "$file_path" ]; then     # ! -f означает "файл НЕ существует"
        print_message "Файл $file_path не найден!" "ERROR"
        return 1
    fi
    
    # -*-*- ЗАГОЛОВОК ОТЧЕТА -*-*-
    {
        echo "=== ФОРЕНСИЧЕСКИЙ ОТЧЕТ ХЭШ-СУММ ==="
        echo "Время создания: $(date '+%Y-%m-%d %H:%M:%S')"
        echo "Файл: $file_path"
        echo "Размер: $(du -h "$file_path" | cut -f1)"
        echo "Путь: $(pwd)"
        echo "Устройство: $(uname -n)"  # uname -n показывает имя хоста
        echo ""
    } > "$output_file"  # > создает/перезаписывает файл
    
    # -*-*- РАСЧЕТ РАЗЛИЧНЫХ ХЭШЕЙ -*-*-
    print_message "Вычисляем MD5..."
    echo "MD5:" >> "$output_file"
    md5sum "$file_path" >> "$output_file"
    echo "" >> "$output_file"
    
    print_message "Вычисляем SHA1..."
    echo "SHA1:" >> "$output_file"
    sha1sum "$file_path" >> "$output_file"
    echo "" >> "$output_file"
    
    print_message "Вычисляем SHA256..."
    echo "SHA256:" >> "$output_file"
    sha256sum "$file_path" >> "$output_file"
    echo "" >> "$output_file"
    
    print_message "Вычисляем SHA512..."
    echo "SHA512:" >> "$output_file"
    sha512sum "$file_path" >> "$output_file"
    echo "" >> "$output_file"
}

# -*-*- ФУНКЦИЯ ВЕРИФИКАЦИИ -*-*-
verify_hashes() {
    local file_path=$1
    local hash_file=$2
    
    print_message "Проверяем целостность файла..."
    
    # Извлекаем ожидаемый SHA256 из файла
    expected_sha256=$(grep -A1 "SHA256:" "$hash_file" | tail -n1 | awk '{print $1}')
    # grep -A1 ищет строку и выводит 1 строку после нее
    # tail -n1 берет последнюю строку
    # awk '{print $1}' берет первое слово (сам хэш)
    
    # Вычисляем текущий SHA256
    current_sha256=$(sha256sum "$file_path" | awk '{print $1}')
    
    # Сравниваем
    if [ "$expected_sha256" = "$current_sha256" ]; then
        print_message "✓ Целостность файла подтверждена!" "SUCCESS"
        return 0
    else
        print_message "✗ Целостность файла нарушена!" "ERROR"
        echo "Ожидалось: $expected_sha256"
        echo "Получено:  $current_sha256"
        return 1
    fi
}

# -*-*- ОСНОВНОЙ КОД -*-*-
cd "$WORK_DIR" || exit 1

# Проверяем существование дампа
if [ ! -f "$DUMP_FILE" ]; then
    print_message "Файл дампа $DUMP_FILE не найден!" "ERROR"
    echo "Сначала выполните сбор дампа: ./start_capture.sh"
    exit 1
fi

# -*-*- РАСЧЕТ ХЭШЕЙ -*-*-
HASH_FILE="hashes_${TIMESTAMP}.txt"  # Добавляем timestamp к имени файла
calculate_hashes "$DUMP_FILE" "$HASH_FILE"

# -*-*- ВЫВОД РЕЗУЛЬТАТОВ -*-*-
echo ""
echo "=== РЕЗУЛЬТАТЫ ==="
cat "$HASH_FILE"  # Выводим содержимое файла в консоль
echo ""

# -*-*- ВЕРИФИКАЦИЯ -*-*-
verify_hashes "$DUMP_FILE" "$HASH_FILE"

# -*-*- СОЗДАНИЕ РЕЗЕРВНОЙ КОПИИ -*-*-
BACKUP_DIR="backups"
mkdir -p "$BACKUP_DIR"
cp "$HASH_FILE" "$BACKUP_DIR/"
print_message "Резервная копия хэшей сохранена в: $BACKUP_DIR/"

print_message "Процесс завершен! Файл хэшей: $HASH_FILE" "SUCCESS"
```

## Файл конфигурации: `config.cfg`

```bash
#!/bin/bash
# Файл конфигурации для скриптов сбора RAM

# Сетевые настройки
TARGET_IP="192.168.1.10"    # IP целевой машины (Ubuntu)
KALI_IP="192.168.1.11"      # IP машины исследователя (Kali)

# Пути и порты
WORK_DIR="/root/ram_capture" # Рабочая директория
PORT="8080"                  # Порт для HTTP сервера

# Дополнительные настройки
MAX_WAIT_TIME=300           # Максимальное время ожидания в секундах
ENABLE_LOGGING="true"       # Включить логирование
LOG_FILE="ram_capture.log"  # Файл лога
```

## Как использовать:

1. **Сделайте скрипты исполняемыми:**
```bash
chmod +x *.sh
```

2. **Запустите по порядку:**
```bash
./prepare_environment.sh    # Подготовка
./start_capture.sh         # Сбор дампа  
./calculate_hashes.sh      # Расчет хэшей
```

3. **Проверьте результаты:**
```bash
ls -la /root/ram_capture/
cat /root/ram_capture/hashes_*.txt
```

